# ChatGPT Work + Codex Harness Research Package

**Created:** 2026-07-18  
**Phase:** research only  
**Implementation:** not started

This package answers the first stage of the long-running-agent-harness brief:

1. a 30-source OpenAI/Anthropic matrix;
2. the ten required architecture comparisons;
3. a separate analysis of what applies natively or by adaptation to ChatGPT Work;
4. a resumable UPE research-state checkpoint.

## Files

- `docs/research/source-matrix.md` — all 30 primary sources, exact repository commits, limitations, decisions, and Work transfer notes.
- `docs/research/pattern-comparison.md` — the ten mandatory comparisons and the recommended v0 boundary.
- `docs/research/chatgpt-work-applicability.md` — Work-native capabilities, limits, project layout, research workflow, Codex merge protocol, and capability scan.
- `docs/research/research-state.yaml` — PASS/UNKNOWN ledger, unresolved inputs, recovery, and next action.
- `validation-report.json` — deterministic package checks.
- `MANIFEST.sha256` — checksums for the package files.

## Main result

```text
ChatGPT Work
  = research, project knowledge, long deliverables, review, scheduling, steering, approvals

Codex + trusted WSL2 host
  = repository execution, worktrees, typed state, validation, budgets, retry, recovery, audit

Shared source of truth
  = versioned goal/state/evidence/decision artifacts
```

## Required next step

Merge Codex’s direct target-environment research and exact runtime observations into the stable source IDs, then create `docs/architecture/ADR-001-harness-boundary.md`. Broad implementation remains blocked by the brief until that ADR exists.
